
const express = require("express")
const router = express.Router()

let users = []

router.post("/signup",(req,res)=>{

const {email,password} = req.body

users.push({
email,
password,
balance:0
})

res.json({message:"Account created"})

})

router.post("/login",(req,res)=>{

const {email,password} = req.body

const user = users.find(u=>u.email===email && u.password===password)

if(!user) return res.status(401).json({error:"Invalid login"})

res.json({message:"Login success",balance:user.balance})

})

module.exports = router
