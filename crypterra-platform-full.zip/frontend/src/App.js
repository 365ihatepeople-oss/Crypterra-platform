
import React from "react"
import Home from "./pages/Home"
import Dashboard from "./pages/Dashboard"

function App(){
  const loggedIn = false
  return(
    <div>
      {loggedIn ? <Dashboard/> : <Home/>}
    </div>
  )
}

export default App
