
import React, { useEffect, useState } from "react"

function PriceTicker(){

const [prices,setPrices] = useState({})

useEffect(()=>{
fetch("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd")
.then(res=>res.json())
.then(data=>setPrices(data))
},[])

return(
<div>
BTC: ${prices?.bitcoin?.usd} <br/>
ETH: ${prices?.ethereum?.usd}
</div>
)
}

export default PriceTicker
