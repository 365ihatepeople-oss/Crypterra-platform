
import React from "react"
import PriceTicker from "../components/PriceTicker"

function Home(){
  return(
    <div>
      <h1>Crypterra Capital</h1>
      <PriceTicker/>
      <p>Professional digital asset portfolio platform.</p>
    </div>
  )
}

export default Home
