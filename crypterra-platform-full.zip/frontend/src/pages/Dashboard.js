
import React from "react"
import PriceTicker from "../components/PriceTicker"

function Dashboard(){
  return(
    <div>
      <h1>Crypterra Dashboard</h1>
      <PriceTicker/>
      <p>Portfolio Balance: $0.00</p>
    </div>
  )
}

export default Dashboard
